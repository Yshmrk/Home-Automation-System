export const TEMPERATURE = "temperature";
export const SCALE = "scale";
export const MODE = "mode";

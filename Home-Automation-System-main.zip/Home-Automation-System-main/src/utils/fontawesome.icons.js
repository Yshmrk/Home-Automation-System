import {
  faCouch,
  faUtensils,
  faBed,
  faBook,
  faBath,
  faBreadSlice,
  faSnowflake,
  faSun,
  faFan
} from "@fortawesome/free-solid-svg-icons";

export default {
  faCouch,
  faUtensils,
  faBed,
  faBook,
  faBath,
  faBreadSlice,
  faSnowflake,
  faSun,
  faFan
};

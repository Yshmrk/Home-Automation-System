import React from "react";

export default function NavigationItem(props) {
  return <li>{props.children}</li>;
}
